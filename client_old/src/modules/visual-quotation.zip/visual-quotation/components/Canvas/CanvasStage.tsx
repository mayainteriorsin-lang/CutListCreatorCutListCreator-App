import React, { useEffect, useMemo, useRef, useState } from "react";
import { Stage, Layer, Rect, Image as KonvaImage, Text, Transformer, Arrow, Line, Circle } from "react-konva";
import useImage from "use-image";
import type { AiInteriorComponentType, LoftDragEdge } from "../../store/visualQuotationStore";
import { LOFT_GAP_MM, SHUTTER_GAP_MM, SIDE_GAP_MM, clampBoxSize, useVisualQuotationStore } from "../../store/visualQuotationStore";

const CANVAS_WIDTH = 900;
const CANVAS_HEIGHT = 500;
const MIN_BOX_SIZE = 50;
const EDGE_HIT_SIZE = 10;
const MIN_SHUTTER_WIDTH_MM = 350;
const GRID_SPACING = 50;
const RULER_SIZE = 20;
const SNAP_GUIDE = 8;
const ROTATE_HANDLE_OFFSET = 30;

type AiComponentRect = {
  id: string;
  type: AiInteriorComponentType;
  x: number;
  y: number;
  width: number;
  height: number;
};

const snapToStep = (value: number, step: number) => Math.round(value / step) * step;

const CanvasStage: React.FC = () => {
  const {
    room,
    roomPhoto,
    wardrobeBox,
    shutterDividerXs,
    loftEnabled,
    loftHeightRatio,
    unitType,
    aiInteriorSuggestion,
    setWardrobeBox,
    setShutterDividerX,
    drawMode,
    setDrawMode,
    scale,
    scaleLine,
    scaleDrawMode,
    setScaleLine,
    setScaleDrawMode,
    wardrobeSpec,
    status,
    loftBox,
    isCornerResizing,
    edgeResizeOnly,
    toggleEdgeResizeOnly,
    ensureLoftBoxForWardrobe,
    startLoftDrag,
    updateLoftDrag,
    stopLoftDrag,
    lockLoft,
  } = useVisualQuotationStore();
  const [photoImage] = useImage(roomPhoto?.src || "");

  const hasPhoto = Boolean(roomPhoto && photoImage);
  const locked = status === "APPROVED";

  const rectRef = useRef<any>(null);
  const transformerRef = useRef<any>(null);

  const [isDrawing, setIsDrawing] = useState(false);
  const [startPoint, setStartPoint] = useState<{ x: number; y: number } | null>(null);
  const [draftBox, setDraftBox] = useState<{ x: number; y: number; width: number; height: number } | null>(null);
  const [scaleStart, setScaleStart] = useState<{ x: number; y: number } | null>(null);
  const [scaleDraft, setScaleDraft] = useState<{ x1: number; y1: number; x2: number; y2: number } | null>(null);
  const [guides, setGuides] = useState<{ vertical: number[]; horizontal: number[] }>({
    vertical: [],
    horizontal: [],
  });
  const [hoveredHandleId, setHoveredHandleId] = useState<string | null>(null);
  const scaleRatio = scale?.ratio ?? 0;
  const gapRatio = scale?.ratio ?? room.scale.pxToMm ?? 0;
  const mmRatio = gapRatio;
  const loftGapPx = gapRatio > 0 ? LOFT_GAP_MM / gapRatio : LOFT_GAP_MM;
  const loftLineY = wardrobeBox ? wardrobeBox.y + wardrobeBox.height * loftHeightRatio : 0;
  const bottomStartY = wardrobeBox
    ? loftEnabled
      ? Math.min(loftLineY + loftGapPx, wardrobeBox.y + wardrobeBox.height)
      : wardrobeBox.y
    : 0;
  const shutterMetrics =
    wardrobeBox && unitType === "wardrobe"
      ? (() => {
          if (!shutterDividerXs.length) return null;
          const dividerXs = [...shutterDividerXs].sort((a, b) => a - b);
          const sideGapPx = gapRatio > 0 ? SIDE_GAP_MM / gapRatio : SIDE_GAP_MM;
          const shutterGapPx = gapRatio > 0 ? SHUTTER_GAP_MM / gapRatio : SHUTTER_GAP_MM;
          const rightEdge = wardrobeBox.x + wardrobeBox.width;
          const widths: number[] = [];
          const centers: number[] = [];
          for (let i = 0; i <= dividerXs.length; i += 1) {
            const left = i === 0 ? wardrobeBox.x + sideGapPx : dividerXs[i - 1] + shutterGapPx;
            const right = i < dividerXs.length ? dividerXs[i] : rightEdge - sideGapPx;
            const width = right - left;
            if (width <= 0) return null;
            widths.push(width);
            centers.push(left + width / 2);
          }
          return { widths, centers };
        })()
      : null;
  const snapStepPx = mmRatio > 0 ? 10 / mmRatio : 10;
  const dividerSnapPx = mmRatio > 0 ? 5 / mmRatio : 5;
  const minShutterWidthPx = mmRatio > 0 ? MIN_SHUTTER_WIDTH_MM / mmRatio : MIN_SHUTTER_WIDTH_MM;

  const dimensions = useMemo(() => {
    if (!roomPhoto || !photoImage || photoImage.width === 0 || photoImage.height === 0) {
      return {
        renderWidth: 0,
        renderHeight: 0,
        offsetX: 0,
        offsetY: 0,
      };
    }

    const scale = Math.min(CANVAS_WIDTH / roomPhoto.width, CANVAS_HEIGHT / roomPhoto.height);
    const renderWidth = roomPhoto.width * scale;
    const renderHeight = roomPhoto.height * scale;

    return {
      renderWidth,
      renderHeight,
      offsetX: (CANVAS_WIDTH - renderWidth) / 2,
      offsetY: (CANVAS_HEIGHT - renderHeight) / 2,
    };
  }, [roomPhoto, photoImage]);

  const photoBounds = useMemo(
    () => ({
      x: dimensions.offsetX,
      y: dimensions.offsetY,
      width: dimensions.renderWidth,
      height: dimensions.renderHeight,
    }),
    [dimensions]
  );

  const gridPositions = useMemo(() => {
    const vertical: number[] = [];
    const horizontal: number[] = [];
    for (let x = 0; x <= CANVAS_WIDTH; x += GRID_SPACING) vertical.push(x);
    for (let y = 0; y <= CANVAS_HEIGHT; y += GRID_SPACING) horizontal.push(y);
    return { vertical, horizontal };
  }, []);

  const aiComponentRects = useMemo<AiComponentRect[]>(() => {
    if (!roomPhoto || !wardrobeBox) return [];
    if (!aiInteriorSuggestion?.detected || unitType === "wardrobe") return [];
    if (!dimensions.renderWidth || !dimensions.renderHeight) return [];

    const clamp01 = (value: number) => Math.min(Math.max(value, 0), 1);

    return aiInteriorSuggestion.components
      .map<AiComponentRect | null>((component, index) => {
        const xNorm = clamp01(component.box.xNorm);
        const yNorm = clamp01(component.box.yNorm);
        const wNorm = clamp01(component.box.wNorm);
        const hNorm = clamp01(component.box.hNorm);
        if (wNorm <= 0 || hNorm <= 0) return null;

        return {
          id: `${component.type}-${index}`,
          type: component.type,
          x: dimensions.offsetX + xNorm * dimensions.renderWidth,
          y: dimensions.offsetY + yNorm * dimensions.renderHeight,
          width: wNorm * dimensions.renderWidth,
          height: hNorm * dimensions.renderHeight,
        };
      })
      .filter((rect): rect is AiComponentRect => rect !== null);
  }, [aiInteriorSuggestion, dimensions, roomPhoto, unitType, wardrobeBox]);

  const clearGuides = () => setGuides({ vertical: [], horizontal: [] });

  const getHandleStyle = (id: string, hoverFill: string, shadowColor: string) => {
    const isHovered = hoveredHandleId === id;
    return {
      fill: isHovered ? hoverFill : "white",
      shadowColor: isHovered ? shadowColor : "transparent",
      shadowBlur: isHovered ? 8 : 0,
      shadowOpacity: isHovered ? 1 : 0,
    };
  };

  const wardrobeHandleStyle = (id: string) => getHandleStyle(id, "#e6f0ff", "rgba(0,116,255,0.5)");
  const loftHandleStyle = (id: string) => getHandleStyle(id, "#f5f5f5", "rgba(0,0,0,0.35)");

  const computeGuidesForBox = (
    activeBox: { x: number; y: number; width: number; height: number },
    otherBox?: { x: number; y: number; width: number; height: number }
  ) => {
    const verticalTargets = new Set<number>();
    const horizontalTargets = new Set<number>();

    if (otherBox) {
      verticalTargets.add(otherBox.x);
      verticalTargets.add(otherBox.x + otherBox.width);
      verticalTargets.add(otherBox.x + otherBox.width / 2);
      horizontalTargets.add(otherBox.y);
      horizontalTargets.add(otherBox.y + otherBox.height);
      horizontalTargets.add(otherBox.y + otherBox.height / 2);
    }

    shutterDividerXs.forEach((x) => verticalTargets.add(x));
    verticalTargets.add(CANVAS_WIDTH / 2);
    horizontalTargets.add(CANVAS_HEIGHT / 2);

    const activeXs = [activeBox.x, activeBox.x + activeBox.width, activeBox.x + activeBox.width / 2];
    const activeYs = [activeBox.y, activeBox.y + activeBox.height, activeBox.y + activeBox.height / 2];

    const vertical = new Set<number>();
    const horizontal = new Set<number>();

    activeXs.forEach((x) => {
      verticalTargets.forEach((target) => {
        if (Math.abs(x - target) < SNAP_GUIDE) vertical.add(target);
      });
    });

    activeYs.forEach((y) => {
      horizontalTargets.forEach((target) => {
        if (Math.abs(y - target) < SNAP_GUIDE) horizontal.add(target);
      });
    });

    return { vertical: Array.from(vertical), horizontal: Array.from(horizontal) };
  };

  const canDrawWardrobe = drawMode && hasPhoto && !locked && !wardrobeBox;
  const canDrawScale = scaleDrawMode && hasPhoto && !locked;

  const clampPointToPhoto = (point: { x: number; y: number }) => {
    if (!hasPhoto) return { ...point, inside: false };
    const x = Math.min(Math.max(point.x, photoBounds.x), photoBounds.x + photoBounds.width);
    const y = Math.min(Math.max(point.y, photoBounds.y), photoBounds.y + photoBounds.height);
    const inside =
      point.x >= photoBounds.x &&
      point.x <= photoBounds.x + photoBounds.width &&
      point.y >= photoBounds.y &&
      point.y <= photoBounds.y + photoBounds.height;
    return { x, y, inside };
  };

  const clampBoxToPhoto = (box: { x: number; y: number; width: number; height: number }) => {
    if (!hasPhoto) return box;

    const width = Math.min(box.width, photoBounds.width);
    const height = Math.min(box.height, photoBounds.height);
    const x = Math.min(
      Math.max(box.x, photoBounds.x),
      photoBounds.x + photoBounds.width - width
    );
    const y = Math.min(
      Math.max(box.y, photoBounds.y),
      photoBounds.y + photoBounds.height - height
    );

    return { x, y, width, height };
  };

  const handleMouseDown = (e: any) => {
    const stage = e.target.getStage();
    const pos = stage?.getPointerPosition();
    if (!pos) return;

    if (canDrawScale) {
      const bounded = clampPointToPhoto(pos);
      if (!bounded.inside) {
        setScaleDrawMode(false);
        return;
      }
      setScaleStart({ x: bounded.x, y: bounded.y });
      setScaleDraft(null);
      return;
    }

    if (!canDrawWardrobe) return;
    const bounded = clampPointToPhoto(pos);
    if (!bounded.inside) {
      setDrawMode(false);
      return;
    }

    setIsDrawing(true);
    setStartPoint({ x: bounded.x, y: bounded.y });
    setDraftBox({ x: bounded.x, y: bounded.y, width: 0, height: 0 });
  };

  const handleMouseMove = (e: any) => {
    const stage = e.target.getStage();
    const pos = stage?.getPointerPosition();
    if (!pos) return;

    if (scaleStart && canDrawScale) {
      const bounded = clampPointToPhoto(pos);
      setScaleDraft({ x1: scaleStart.x, y1: scaleStart.y, x2: bounded.x, y2: bounded.y });
      return;
    }

    if (!isDrawing || !startPoint) return;
    const bounded = clampPointToPhoto(pos);
    const x = Math.min(startPoint.x, bounded.x);
    const y = Math.min(startPoint.y, bounded.y);
    const width = Math.abs(bounded.x - startPoint.x);
    const height = Math.abs(bounded.y - startPoint.y);

    setDraftBox({ x, y, width, height });
  };

  const finalizeDraft = () => {
    if (draftBox && draftBox.width >= MIN_BOX_SIZE && draftBox.height >= MIN_BOX_SIZE) {
      const clamped = clampBoxToPhoto(draftBox);
      setWardrobeBox(clamped);
    }
    setDraftBox(null);
    setStartPoint(null);
    setIsDrawing(false);
    setDrawMode(false);
  };

  const finalizeScaleDraft = () => {
    if (!scaleStart || !scaleDraft) return;
    const line = { ...scaleDraft };
    const lengthPx = Math.hypot(line.x2 - line.x1, line.y2 - line.y1);
    if (lengthPx <= 5) {
      setScaleLine(undefined);
      setScaleDrawMode(false);
    } else {
      setScaleLine({ ...line, lengthPx });
    }
    setScaleDraft(null);
    setScaleStart(null);
    setScaleDrawMode(false);
  };

  const handleMouseUp = () => {
    if (scaleStart && canDrawScale) {
      finalizeScaleDraft();
      return;
    }
    if (!isDrawing) return;
    finalizeDraft();
  };

  useEffect(() => {
    if (!drawMode) {
      setIsDrawing(false);
      setStartPoint(null);
      setDraftBox(null);
    }
  }, [drawMode]);

  useEffect(() => {
    if (transformerRef.current && rectRef.current && wardrobeBox && !locked) {
      transformerRef.current.nodes([rectRef.current]);
      transformerRef.current.getLayer()?.batchDraw();
    } else if (transformerRef.current) {
      transformerRef.current.nodes([]);
      transformerRef.current.getLayer()?.batchDraw();
    }
  }, [wardrobeBox, locked]);

  useEffect(() => {
    if (!scaleDrawMode) {
      setScaleStart(null);
      setScaleDraft(null);
    }
  }, [scaleDrawMode]);

  useEffect(() => {
    if (unitType === "wardrobe" && wardrobeBox) {
      ensureLoftBoxForWardrobe();
    }
  }, [unitType, wardrobeBox, ensureLoftBoxForWardrobe]);

  const handleDragMove = (e: any) => {
    if (!hasPhoto) return;
    const newBox = clampBoxToPhoto({
      x: e.target.x(),
      y: e.target.y(),
      width: e.target.width(),
      height: e.target.height(),
    });
    e.target.position({ x: newBox.x, y: newBox.y });
  };

  const handleDragEnd = (e: any) => {
    if (!hasPhoto || locked) return;
    const newBox = clampBoxToPhoto({
      x: e.target.x(),
      y: e.target.y(),
      width: e.target.width(),
      height: e.target.height(),
    });
    setWardrobeBox(newBox);
  };

  const handleTransformEnd = () => {
    if (!rectRef.current || !hasPhoto || locked) return;
    const node = rectRef.current;
    const scaleX = node.scaleX();
    const scaleY = node.scaleY();

    const width = Math.max(node.width() * scaleX, MIN_BOX_SIZE);
    const height = Math.max(node.height() * scaleY, MIN_BOX_SIZE);

    node.scaleX(1);
    node.scaleY(1);

    const newBox = clampBoxToPhoto({
      x: node.x(),
      y: node.y(),
      width,
      height,
    });

    node.position({ x: newBox.x, y: newBox.y });
    node.width(newBox.width);
    node.height(newBox.height);

    setWardrobeBox(newBox);
  };

  const clampDividerX = (index: number, x: number) => {
    if (!wardrobeBox || shutterDividerXs.length === 0) return x;
    const leftEdge = wardrobeBox.x;
    const rightEdge = wardrobeBox.x + wardrobeBox.width;
    const leftNeighbor = index > 0 ? shutterDividerXs[index - 1] : leftEdge;
    const rightNeighbor = index < shutterDividerXs.length - 1 ? shutterDividerXs[index + 1] : rightEdge;
    const minX = leftNeighbor + minShutterWidthPx;
    const maxX = rightNeighbor - minShutterWidthPx;
    if (minX > maxX) return Math.min(Math.max(x, leftEdge), rightEdge);
    return Math.min(Math.max(x, minX), maxX);
  };

  const applyDividerDrag = (index: number, x: number, snap: boolean) => {
    if (index < 0 || index >= shutterDividerXs.length) return x;
    const clamped = clampDividerX(index, x);
    const snapped =
      snap && dividerSnapPx > 0 ? snapToStep(clamped, dividerSnapPx) : clamped;
    const finalX = clampDividerX(index, snapped);
    setShutterDividerX(index, finalX);
    return finalX;
  };

  const updateLeftEdge = (edgeX: number, snap: boolean) => {
    if (!wardrobeBox || !hasPhoto || locked) return;
    const right = wardrobeBox.x + wardrobeBox.width;
    const step = snap ? snapStepPx : 0;
    const snapped = snap && step > 0 ? snapToStep(edgeX, step) : edgeX;
    const minX = photoBounds.x;
    const maxX = right - MIN_BOX_SIZE;
    const newLeft = Math.min(Math.max(snapped, minX), maxX);
    setWardrobeBox({
      x: newLeft,
      y: wardrobeBox.y,
      width: right - newLeft,
      height: wardrobeBox.height,
    });
  };

  const updateRightEdge = (edgeX: number, snap: boolean) => {
    if (!wardrobeBox || !hasPhoto || locked) return;
    const left = wardrobeBox.x;
    const step = snap ? snapStepPx : 0;
    const snapped = snap && step > 0 ? snapToStep(edgeX, step) : edgeX;
    const minX = left + MIN_BOX_SIZE;
    const maxX = photoBounds.x + photoBounds.width;
    const newRight = Math.min(Math.max(snapped, minX), maxX);
    setWardrobeBox({
      x: left,
      y: wardrobeBox.y,
      width: newRight - left,
      height: wardrobeBox.height,
    });
  };

  const updateTopEdge = (edgeY: number, snap: boolean) => {
    if (!wardrobeBox || !hasPhoto || locked) return;
    const bottom = wardrobeBox.y + wardrobeBox.height;
    const step = snap ? snapStepPx : 0;
    const snapped = snap && step > 0 ? snapToStep(edgeY, step) : edgeY;
    const minY = photoBounds.y;
    const maxY = bottom - MIN_BOX_SIZE;
    const newTop = Math.min(Math.max(snapped, minY), maxY);
    setWardrobeBox({
      x: wardrobeBox.x,
      y: newTop,
      width: wardrobeBox.width,
      height: bottom - newTop,
    });
  };

  const updateBottomEdge = (edgeY: number, snap: boolean) => {
    if (!wardrobeBox || !hasPhoto || locked) return;
    const top = wardrobeBox.y;
    const step = snap ? snapStepPx : 0;
    const snapped = snap && step > 0 ? snapToStep(edgeY, step) : edgeY;
    const minY = top + MIN_BOX_SIZE;
    const maxY = photoBounds.y + photoBounds.height;
    const newBottom = Math.min(Math.max(snapped, minY), maxY);
    setWardrobeBox({
      x: wardrobeBox.x,
      y: top,
      width: wardrobeBox.width,
      height: newBottom - top,
    });
  };

  return (
    <div style={styles.wrapper}>
      <div style={styles.controlsRow}>
        <label style={styles.edgeToggle}>
          <input
            type="checkbox"
            checked={edgeResizeOnly}
            onChange={toggleEdgeResizeOnly}
          />
          <span style={{ marginLeft: 6 }}>Edge Adjust Mode (Left / Right / Bottom)</span>
        </label>
      </div>
      <Stage
        width={CANVAS_WIDTH}
        height={CANVAS_HEIGHT}
        style={styles.stage}
        onMouseDown={handleMouseDown}
        onMouseMove={(e) => {
          const stage = e.target.getStage();
          if (stage) {
            const pos = stage.getPointerPosition();
            if (pos) {
              useVisualQuotationStore.setState({ _loftPointer: { x: pos.x, y: pos.y } } as any);
              const st = useVisualQuotationStore.getState();
              if (!st.isCornerResizing) {
                updateLoftDrag();
              }
              const nextState = useVisualQuotationStore.getState();
              if (nextState.loftBox?.isDragging) {
                setGuides(computeGuidesForBox(nextState.loftBox, nextState.wardrobeBox));
              }
            }
          }
          handleMouseMove(e);
        }}
        onMouseUp={() => {
          stopLoftDrag();
          handleMouseUp();
          clearGuides();
        }}
        onTouchMove={(e) => {
          const stage = e.target.getStage();
          if (stage) {
            const pos = stage.getPointerPosition();
            if (pos) {
              useVisualQuotationStore.setState({ _loftPointer: { x: pos.x, y: pos.y } } as any);
              const st = useVisualQuotationStore.getState();
              if (!st.isCornerResizing) {
                updateLoftDrag();
              }
              const nextState = useVisualQuotationStore.getState();
              if (nextState.loftBox?.isDragging) {
                setGuides(computeGuidesForBox(nextState.loftBox, nextState.wardrobeBox));
              }
            }
          }
        }}
        onTouchEnd={() => {
          stopLoftDrag();
          clearGuides();
        }}
      >
        <Layer>
          {hasPhoto && (
            <KonvaImage
              image={photoImage as HTMLImageElement}
              x={dimensions.offsetX}
              y={dimensions.offsetY}
              width={dimensions.renderWidth}
              height={dimensions.renderHeight}
              draggable={false}
            />
          )}

          {scaleLine && (
            <>
              <Arrow
                points={[scaleLine.x1, scaleLine.y1, scaleLine.x2, scaleLine.y2]}
                stroke="#111827"
                fill="#111827"
                pointerLength={10}
                pointerWidth={10}
                strokeWidth={2}
              />
              <Arrow
                points={[scaleLine.x2, scaleLine.y2, scaleLine.x1, scaleLine.y1]}
                stroke="#111827"
                fill="#111827"
                pointerLength={10}
                pointerWidth={10}
                strokeWidth={2}
              />
              <Text
                x={(scaleLine.x1 + scaleLine.x2) / 2 - 60}
                y={(scaleLine.y1 + scaleLine.y2) / 2 - 20}
                width={120}
                align="center"
                text={
                  scale
                    ? `${scaleLine.lengthPx.toFixed(1)} px / ${(scaleLine.lengthPx * scale.ratio).toFixed(1)} mm`
                    : `${scaleLine.lengthPx.toFixed(1)} px`
                }
                fontSize={12}
                fill="#111827"
              />
            </>
          )}

          {scaleDraft && scaleDrawMode && (
            <Arrow
              points={[scaleDraft.x1, scaleDraft.y1, scaleDraft.x2, scaleDraft.y2]}
              stroke="#6b7280"
              fill="#6b7280"
              pointerLength={10}
              pointerWidth={10}
              strokeWidth={2}
              dash={[6, 6]}
            />
          )}

          {/* Canvas border */}
          <Rect
            x={0}
            y={0}
            width={CANVAS_WIDTH}
            height={CANVAS_HEIGHT}
            stroke="#d1d5db"
            dash={[6, 6]}
          />

          {wardrobeBox && (
            <>
              {unitType === "wardrobe" && loftBox && (
                <>
                  <Rect
                    x={loftBox.x}
                    y={loftBox.y}
                    width={loftBox.width}
                    height={loftBox.height}
                    rotation={loftBox.rotation ?? 0}
                    stroke={loftBox.locked ? "#888" : "#000"}
                    strokeWidth={2}
                    fill={loftBox.locked ? "rgba(0,0,0,0.05)" : "rgba(255,255,255,0.2)"}
                    listening={!loftBox.locked && !isCornerResizing}
                    onMouseDown={(e) => {
                      e.cancelBubble = true;
                      if (loftBox.locked || locked) return;
                      const stage = e.target.getStage();
                      const pos = stage.getPointerPosition();
                      if (!pos) return;

                      const EDGE = 10;
                      const { x, y, width, height } = loftBox;
                      const px = pos.x;
                      const py = pos.y;

                      const nearLeft = Math.abs(px - x) <= EDGE;
                      const nearRight = Math.abs(px - (x + width)) <= EDGE;
                      const nearTop = Math.abs(py - y) <= EDGE;
                      const nearBottom = Math.abs(py - (y + height)) <= EDGE;

                      let edge: LoftDragEdge | null = null;
                      if (nearLeft) edge = "left";
                      else if (nearRight) edge = "right";
                      else if (nearTop) edge = "top";
                      else if (nearBottom) edge = "bottom";
                      else if (px > x && px < x + width && py > y && py < y + height) {
                        edge = "move";
                      }

                      if (edge) {
                        useVisualQuotationStore.setState({ _loftPointer: { x: px, y: py } } as any);
                        if (!useVisualQuotationStore.getState().isCornerResizing) {
                          startLoftDrag(edge);
                        }
                      }
                    }}
                    onTouchStart={(e) => {
                      e.cancelBubble = true;
                      if (loftBox.locked || locked) return;
                      const stage = e.target.getStage();
                      const pos = stage.getPointerPosition();
                      if (!pos) return;
                      const EDGE = 10;
                      const { x, y, width, height } = loftBox;
                      const px = pos.x;
                      const py = pos.y;

                      const nearLeft = Math.abs(px - x) <= EDGE;
                      const nearRight = Math.abs(px - (x + width)) <= EDGE;
                      const nearTop = Math.abs(py - y) <= EDGE;
                      const nearBottom = Math.abs(py - (y + height)) <= EDGE;

                      let edge: LoftDragEdge | null = null;
                      if (nearLeft) edge = "left";
                      else if (nearRight) edge = "right";
                      else if (nearTop) edge = "top";
                      else if (nearBottom) edge = "bottom";
                      else if (px > x && px < x + width && py > y && py < y + height) {
                        edge = "move";
                      }

                      if (edge) {
                        useVisualQuotationStore.setState({ _loftPointer: { x: px, y: py } } as any);
                        if (!useVisualQuotationStore.getState().isCornerResizing) {
                          startLoftDrag(edge);
                        }
                      }
                    }}
                    onMouseUp={() => {
                      stopLoftDrag();
                    }}
                    onTouchEnd={() => {
                      stopLoftDrag();
                    }}
                    onMouseEnter={(e) => {
                      const stage = e.target.getStage();
                      if (!stage || loftBox.locked) return;

                      const container = stage.container();
                      if (loftBox.dragEdge === "left" || loftBox.dragEdge === "right") {
                        container.style.cursor = "ew-resize";
                      } else if (loftBox.dragEdge === "top" || loftBox.dragEdge === "bottom") {
                        container.style.cursor = "ns-resize";
                      } else if (loftBox.dragEdge === "move") {
                        container.style.cursor = "move";
                      } else {
                        container.style.cursor = "pointer";
                      }
                    }}
                    onMouseLeave={(e) => {
                      const stage = e.target.getStage();
                      if (stage) stage.container().style.cursor = "default";
                    }}
                  />
                  <Text
                    x={loftBox.x + 4}
                    y={loftBox.y + 4}
                    text={`${Math.round(loftBox.width)} × ${Math.round(loftBox.height)}`}
                    fontSize={12}
                    fill="#333"
                    listening={false}
                  />
                  <Circle
                    id="loft-corner-tl"
                    x={loftBox.x}
                    y={loftBox.y}
                    radius={6}
                    fill="white"
                    stroke="#111111"
                    strokeWidth={2}
                    draggable
                    listening={true}
                    hitStrokeWidth={35}
                    dragBoundFunc={(pos) => pos}
                    onMouseDown={(e) => {
                      e.cancelBubble = true;
                      useVisualQuotationStore.getState().startCornerResize();
                    }}
                    onDragMove={(e) => {
                      const stage = e.target.getStage();
                      const pos = stage.getPointerPosition();
                      if (!pos) return;
                      const newX = pos.x;
                      const newY = pos.y;

                      useVisualQuotationStore.setState((s) => {
                        const box = s.loftBox;
                        if (!box || box.locked) return s;
                        const oldX = box.x;
                        const oldY = box.y;
                        const oldW = box.width;
                        const oldH = box.height;
                        const width = oldW + (oldX - newX);
                        const height = oldH + (oldY - newY);
                        const clamped = clampBoxSize(width, height);
                        const updated = {
                          ...box,
                          x: newX,
                          y: newY,
                          width: clamped.width,
                          height: clamped.height,
                        };
                        return { loftBox: updated };
                      });

                      e.target.getLayer().batchDraw();
                    }}
                    onDragEnd={(e) => {
                      useVisualQuotationStore.getState().stopCornerResize();
                    }}
                    onMouseUp={(e) => {
                      useVisualQuotationStore.getState().stopCornerResize();
                    }}
                  />
                  <Circle
                    id="loft-corner-tr"
                    x={loftBox.x + loftBox.width}
                    y={loftBox.y}
                    radius={6}
                    fill="white"
                    stroke="#111111"
                    strokeWidth={2}
                    draggable
                    listening={true}
                    hitStrokeWidth={35}
                    dragBoundFunc={(pos) => pos}
                    onMouseDown={(e) => {
                      e.cancelBubble = true;
                      useVisualQuotationStore.getState().startCornerResize();
                    }}
                    onDragMove={(e) => {
                      const stage = e.target.getStage();
                      const pos = stage.getPointerPosition();
                      if (!pos) return;
                      const newX = pos.x;
                      const newY = pos.y;

                      useVisualQuotationStore.setState((s) => {
                        const box = s.loftBox;
                        if (!box || box.locked) return s;
                        const oldX = box.x;
                        const oldY = box.y;
                        const oldH = box.height;
                        const width = newX - oldX;
                        const height = oldH + (oldY - newY);
                        const clamped = clampBoxSize(width, height);
                        const updated = {
                          ...box,
                          x: oldX,
                          y: newY,
                          width: clamped.width,
                          height: clamped.height,
                        };
                        return { loftBox: updated };
                      });

                      e.target.getLayer().batchDraw();
                    }}
                    onDragEnd={(e) => {
                      useVisualQuotationStore.getState().stopCornerResize();
                    }}
                    onMouseUp={(e) => {
                      useVisualQuotationStore.getState().stopCornerResize();
                    }}
                  />
                  <Circle
                    id="loft-corner-bl"
                    x={loftBox.x}
                    y={loftBox.y + loftBox.height}
                    radius={6}
                    fill="white"
                    stroke="#111111"
                    strokeWidth={2}
                    draggable
                    listening={true}
                    hitStrokeWidth={35}
                    dragBoundFunc={(pos) => pos}
                    onMouseDown={(e) => {
                      e.cancelBubble = true;
                      useVisualQuotationStore.getState().startCornerResize();
                    }}
                    onDragMove={(e) => {
                      const stage = e.target.getStage();
                      const pos = stage.getPointerPosition();
                      if (!pos) return;
                      const newX = pos.x;
                      const newY = pos.y;

                      useVisualQuotationStore.setState((s) => {
                        const box = s.loftBox;
                        if (!box || box.locked) return s;
                        const oldX = box.x;
                        const oldY = box.y;
                        const oldW = box.width;
                        const width = oldW + (oldX - newX);
                        const height = newY - oldY;
                        const clamped = clampBoxSize(width, height);
                        const updated = {
                          ...box,
                          x: newX,
                          y: oldY,
                          width: clamped.width,
                          height: clamped.height,
                        };
                        return { loftBox: updated };
                      });

                      e.target.getLayer().batchDraw();
                    }}
                    onDragEnd={(e) => {
                      useVisualQuotationStore.getState().stopCornerResize();
                    }}
                    onMouseUp={(e) => {
                      useVisualQuotationStore.getState().stopCornerResize();
                    }}
                  />
                  <Circle
                    id="loft-corner-br"
                    x={loftBox.x + loftBox.width}
                    y={loftBox.y + loftBox.height}
                    radius={6}
                    fill="white"
                    stroke="#111111"
                    strokeWidth={2}
                    draggable
                    listening={true}
                    hitStrokeWidth={35}
                    dragBoundFunc={(pos) => pos}
                    onMouseDown={(e) => {
                      e.cancelBubble = true;
                      useVisualQuotationStore.getState().startCornerResize();
                    }}
                    onDragMove={(e) => {
                      const stage = e.target.getStage();
                      const pos = stage.getPointerPosition();
                      if (!pos) return;
                      const newX = pos.x;
                      const newY = pos.y;

                      useVisualQuotationStore.setState((s) => {
                        const box = s.loftBox;
                        if (!box || box.locked) return s;
                        const oldX = box.x;
                        const oldY = box.y;
                        const width = newX - oldX;
                        const height = newY - oldY;
                        const clamped = clampBoxSize(width, height);
                        const updated = {
                          ...box,
                          x: oldX,
                          y: oldY,
                          width: clamped.width,
                          height: clamped.height,
                        };
                        return { loftBox: updated };
                      });

                      e.target.getLayer().batchDraw();
                    }}
                    onDragEnd={(e) => {
                      useVisualQuotationStore.getState().stopCornerResize();
                    }}
                    onMouseUp={(e) => {
                      useVisualQuotationStore.getState().stopCornerResize();
                    }}
                  />
                </>
              )}

              <Rect
                ref={rectRef}
                x={wardrobeBox.x}
                y={wardrobeBox.y}
                width={wardrobeBox.width}
                height={wardrobeBox.height}
                stroke="#000"
                strokeWidth={3}
                fill="rgba(0, 0, 0, 0.03)"
                listening={!isCornerResizing}
                draggable={!locked}
                dragBoundFunc={(pos) =>
                  (() => {
                    const clamped = clampBoxToPhoto({
                      x: pos.x,
                      y: pos.y,
                      width: wardrobeBox.width,
                      height: wardrobeBox.height,
                    });
                    return { x: clamped.x, y: clamped.y };
                  })()
                }
                onDragMove={(e) => {
                  if (useVisualQuotationStore.getState().isCornerResizing) return;
                  handleDragMove(e);
                  const box = e.target;
                  const current = useVisualQuotationStore.getState().wardrobeBox ?? wardrobeBox;
                  if (current) {
                    const nextBox = { ...current, x: box.x(), y: box.y() };
                    setGuides(computeGuidesForBox(nextBox, loftBox));
                  }
                  useVisualQuotationStore.setState((s) => {
                    const current = s.wardrobeBox ?? wardrobeBox;
                    if (!current) return {};
                    return {
                      wardrobeBox: {
                        ...current,
                        x: box.x(),
                        y: box.y(),
                      },
                    };
                  });
                }}
                onDragEnd={(e) => {
                  handleDragEnd(e);
                  clearGuides();
                }}
                onTransformEnd={handleTransformEnd}
              />
              {!edgeResizeOnly && (
                <>
                  <Circle
                    id="wardrobe-corner-tl"
                    x={wardrobeBox.x}
                    y={wardrobeBox.y}
                    radius={6}
                    fill="white"
                    stroke="#0074ff"
                    strokeWidth={2}
                    draggable
                    listening={true}
                    hitStrokeWidth={35}
                    dragBoundFunc={(pos) => pos}
                    onMouseDown={(e) => {
                      e.cancelBubble = true;
                      useVisualQuotationStore.getState().startCornerResize();
                    }}
                    onDragMove={(e) => {
                      const stage = e.target.getStage();
                      const pos = stage.getPointerPosition();
                      if (!pos) return;
                      const newX = pos.x;
                      const newY = pos.y;

                      useVisualQuotationStore.setState((s) => {
                        const box = s.wardrobeBox;
                        if (!box || locked) return s;
                        const oldX = box.x;
                        const oldY = box.y;
                        const oldW = box.width;
                        const oldH = box.height;
                        const width = oldW + (oldX - newX);
                        const height = oldH + (oldY - newY);
                        const clamped = clampBoxSize(width, height);
                        const updated = {
                          ...box,
                          x: newX,
                          y: newY,
                          width: clamped.width,
                          height: clamped.height,
                        };
                        return { wardrobeBox: updated };
                      });

                      e.target.getLayer().batchDraw();
                    }}
                    onDragEnd={(e) => {
                      useVisualQuotationStore.getState().stopCornerResize();
                    }}
                    onMouseUp={(e) => {
                      useVisualQuotationStore.getState().stopCornerResize();
                    }}
                  />
                  <Circle
                    id="wardrobe-corner-tr"
                    x={wardrobeBox.x + wardrobeBox.width}
                    y={wardrobeBox.y}
                    radius={6}
                    fill="white"
                    stroke="#0074ff"
                    strokeWidth={2}
                    draggable
                    listening={true}
                    hitStrokeWidth={35}
                    dragBoundFunc={(pos) => pos}
                    onMouseDown={(e) => {
                      e.cancelBubble = true;
                      useVisualQuotationStore.getState().startCornerResize();
                    }}
                    onDragMove={(e) => {
                      const stage = e.target.getStage();
                      const pos = stage.getPointerPosition();
                      if (!pos) return;
                      const newX = pos.x;
                      const newY = pos.y;

                      useVisualQuotationStore.setState((s) => {
                        const box = s.wardrobeBox;
                        if (!box || locked) return s;
                        const oldX = box.x;
                        const oldY = box.y;
                        const oldH = box.height;
                        const width = newX - oldX;
                        const height = oldH + (oldY - newY);
                        const clamped = clampBoxSize(width, height);
                        const updated = {
                          ...box,
                          x: oldX,
                          y: newY,
                          width: clamped.width,
                          height: clamped.height,
                        };
                        return { wardrobeBox: updated };
                      });

                      e.target.getLayer().batchDraw();
                    }}
                    onDragEnd={(e) => {
                      useVisualQuotationStore.getState().stopCornerResize();
                    }}
                    onMouseUp={(e) => {
                      useVisualQuotationStore.getState().stopCornerResize();
                    }}
                  />
                  <Circle
                    id="wardrobe-corner-bl"
                    x={wardrobeBox.x}
                    y={wardrobeBox.y + wardrobeBox.height}
                    radius={6}
                    fill="white"
                    stroke="#0074ff"
                    strokeWidth={2}
                    draggable
                    listening={true}
                    hitStrokeWidth={35}
                    dragBoundFunc={(pos) => pos}
                    onMouseDown={(e) => {
                      e.cancelBubble = true;
                      useVisualQuotationStore.getState().startCornerResize();
                    }}
                    onDragMove={(e) => {
                      const stage = e.target.getStage();
                      const pos = stage.getPointerPosition();
                      if (!pos) return;
                      const newX = pos.x;
                      const newY = pos.y;

                      useVisualQuotationStore.setState((s) => {
                        const box = s.wardrobeBox;
                        if (!box || locked) return s;
                        const oldX = box.x;
                        const oldY = box.y;
                        const oldW = box.width;
                        const width = oldW + (oldX - newX);
                        const height = newY - oldY;
                        const clamped = clampBoxSize(width, height);
                        const updated = {
                          ...box,
                          x: newX,
                          y: oldY,
                          width: clamped.width,
                          height: clamped.height,
                        };
                        return { wardrobeBox: updated };
                      });

                      e.target.getLayer().batchDraw();
                    }}
                    onDragEnd={(e) => {
                      useVisualQuotationStore.getState().stopCornerResize();
                    }}
                    onMouseUp={(e) => {
                      useVisualQuotationStore.getState().stopCornerResize();
                    }}
                  />
                  <Circle
                    id="wardrobe-corner-br"
                    x={wardrobeBox.x + wardrobeBox.width}
                    y={wardrobeBox.y + wardrobeBox.height}
                    radius={6}
                    fill="white"
                    stroke="#0074ff"
                    strokeWidth={2}
                    draggable
                    listening={true}
                    hitStrokeWidth={35}
                    dragBoundFunc={(pos) => pos}
                    onMouseDown={(e) => {
                      e.cancelBubble = true;
                      useVisualQuotationStore.getState().startCornerResize();
                    }}
                    onDragMove={(e) => {
                      const stage = e.target.getStage();
                      const pos = stage.getPointerPosition();
                      if (!pos) return;
                      const newX = pos.x;
                      const newY = pos.y;

                      useVisualQuotationStore.setState((s) => {
                        const box = s.wardrobeBox;
                        if (!box || locked) return s;
                        const oldX = box.x;
                        const oldY = box.y;
                        const width = newX - oldX;
                        const height = newY - oldY;
                        const clamped = clampBoxSize(width, height);
                        const updated = {
                          ...box,
                          x: oldX,
                          y: oldY,
                          width: clamped.width,
                          height: clamped.height,
                        };
                        return { wardrobeBox: updated };
                      });

                      e.target.getLayer().batchDraw();
                    }}
                    onDragEnd={(e) => {
                      useVisualQuotationStore.getState().stopCornerResize();
                    }}
                    onMouseUp={(e) => {
                      useVisualQuotationStore.getState().stopCornerResize();
                    }}
                  />
                </>
              )}

              {!isCornerResizing && (
                <Rect
                  x={wardrobeBox.x - EDGE_HIT_SIZE / 2}
                  y={wardrobeBox.y}
                  width={EDGE_HIT_SIZE}
                  height={wardrobeBox.height}
                  fill="rgba(0, 0, 0, 0.01)"
                  draggable={!locked}
                  listening={!locked}
                  dragBoundFunc={(pos) => ({ x: pos.x, y: wardrobeBox.y })}
                  onDragMove={(e) => {
                    if (useVisualQuotationStore.getState().isCornerResizing) return;
                    updateLeftEdge(e.target.x() + EDGE_HIT_SIZE / 2, false);
                  }}
                  onDragEnd={(e) => updateLeftEdge(e.target.x() + EDGE_HIT_SIZE / 2, true)}
                  onMouseEnter={(e) => {
                    const stage = e.target.getStage();
                    if (stage) stage.container().style.cursor = "ew-resize";
                  }}
                  onMouseLeave={(e) => {
                    const stage = e.target.getStage();
                    if (stage) stage.container().style.cursor = "default";
                  }}
                />
              )}
              {!isCornerResizing && (
                <Rect
                  x={wardrobeBox.x + wardrobeBox.width - EDGE_HIT_SIZE / 2}
                  y={wardrobeBox.y}
                  width={EDGE_HIT_SIZE}
                  height={wardrobeBox.height}
                  fill="rgba(0, 0, 0, 0.01)"
                  draggable={!locked}
                  listening={!locked}
                  dragBoundFunc={(pos) => ({ x: pos.x, y: wardrobeBox.y })}
                  onDragMove={(e) => {
                    if (useVisualQuotationStore.getState().isCornerResizing) return;
                    updateRightEdge(e.target.x() + EDGE_HIT_SIZE / 2, false);
                  }}
                  onDragEnd={(e) => updateRightEdge(e.target.x() + EDGE_HIT_SIZE / 2, true)}
                  onMouseEnter={(e) => {
                    const stage = e.target.getStage();
                    if (stage) stage.container().style.cursor = "ew-resize";
                  }}
                  onMouseLeave={(e) => {
                    const stage = e.target.getStage();
                    if (stage) stage.container().style.cursor = "default";
                  }}
                />
              )}
              {!isCornerResizing && !edgeResizeOnly && (
                <Rect
                  x={wardrobeBox.x}
                  y={wardrobeBox.y - EDGE_HIT_SIZE / 2}
                  width={wardrobeBox.width}
                  height={EDGE_HIT_SIZE}
                  fill="rgba(0, 0, 0, 0.01)"
                  draggable={!locked}
                  listening={!locked}
                  dragBoundFunc={(pos) => ({ x: wardrobeBox.x, y: pos.y })}
                  onDragMove={(e) => {
                    if (useVisualQuotationStore.getState().isCornerResizing) return;
                    updateTopEdge(e.target.y() + EDGE_HIT_SIZE / 2, false);
                  }}
                  onDragEnd={(e) => updateTopEdge(e.target.y() + EDGE_HIT_SIZE / 2, true)}
                  onMouseEnter={(e) => {
                    const stage = e.target.getStage();
                    if (stage) stage.container().style.cursor = "ns-resize";
                  }}
                  onMouseLeave={(e) => {
                    const stage = e.target.getStage();
                    if (stage) stage.container().style.cursor = "default";
                  }}
                />
              )}
              {!isCornerResizing && (
                <Rect
                  x={wardrobeBox.x}
                  y={wardrobeBox.y + wardrobeBox.height - EDGE_HIT_SIZE / 2}
                  width={wardrobeBox.width}
                  height={EDGE_HIT_SIZE}
                  fill="rgba(0, 0, 0, 0.01)"
                  draggable={!locked}
                  listening={!locked}
                  dragBoundFunc={(pos) => ({ x: wardrobeBox.x, y: pos.y })}
                  onDragMove={(e) => {
                    if (useVisualQuotationStore.getState().isCornerResizing) return;
                    updateBottomEdge(e.target.y() + EDGE_HIT_SIZE / 2, false);
                  }}
                  onDragEnd={(e) => updateBottomEdge(e.target.y() + EDGE_HIT_SIZE / 2, true)}
                  onMouseEnter={(e) => {
                    const stage = e.target.getStage();
                    if (stage) stage.container().style.cursor = "ns-resize";
                  }}
                  onMouseLeave={(e) => {
                    const stage = e.target.getStage();
                    if (stage) stage.container().style.cursor = "default";
                  }}
                />
              )}

              {unitType === "wardrobe" &&
                shutterDividerXs.map((xPos, idx) => (
                  <Line
                    key={`shutter-divider-${idx}`}
                    x={xPos}
                    y={0}
                    points={[0, bottomStartY, 0, wardrobeBox.y + wardrobeBox.height]}
                    stroke="#333"
                    strokeWidth={2}
                    hitStrokeWidth={EDGE_HIT_SIZE}
                    draggable={!locked}
                    listening={!locked}
                    dragBoundFunc={(pos) => ({ x: clampDividerX(idx, pos.x), y: 0 })}
                    onDragMove={(e) => {
                      const nextX = applyDividerDrag(idx, e.target.x(), false);
                      if (nextX !== e.target.x()) e.target.x(nextX);
                    }}
                    onDragEnd={(e) => {
                      const finalX = applyDividerDrag(idx, e.target.x(), true);
                      e.target.x(finalX);
                    }}
                    onMouseEnter={(e) => {
                      const stage = e.target.getStage();
                      if (stage) stage.container().style.cursor = "ew-resize";
                    }}
                    onMouseLeave={(e) => {
                      const stage = e.target.getStage();
                      if (stage) stage.container().style.cursor = "default";
                    }}
                  />
                ))}

              {unitType === "wardrobe" && loftEnabled && (
                <Line
                  points={[
                    wardrobeBox.x,
                    loftLineY,
                    wardrobeBox.x + wardrobeBox.width,
                    loftLineY,
                  ]}
                  stroke="#333"
                  strokeWidth={2}
                  listening={false}
                />
              )}

              {unitType === "wardrobe" &&
                loftEnabled &&
                shutterDividerXs.map((xPos, idx) => (
                  <Line
                    key={`loft-divider-${idx}`}
                    points={[xPos, wardrobeBox.y, xPos, loftLineY]}
                    stroke="#333"
                    strokeWidth={2}
                    listening={false}
                  />
                ))}

              {unitType === "wardrobe" &&
                shutterMetrics &&
                shutterMetrics.centers.map((xPos, idx) => {
                  const labelWidth = shutterMetrics.widths[idx] ?? 0;
                  const labelX = xPos - labelWidth / 2;
                  const labelY = bottomStartY + 6;
                  const valueY = labelY + 14;
                  return (
                    <React.Fragment key={`shutter-label-${idx}`}>
                      <Text
                        x={labelX}
                        y={labelY}
                        width={labelWidth}
                        align="center"
                        text={`S${idx + 1}`}
                        fontSize={12}
                        fontFamily="Arial"
                        fill="#000"
                        listening={false}
                      />
                      {mmRatio > 0 && (
                        <Text
                          x={labelX}
                          y={valueY}
                          width={labelWidth}
                          align="center"
                          text={`${Math.round(labelWidth * mmRatio)} mm`}
                          fontSize={11}
                          fontFamily="Arial"
                          fill="#000"
                          listening={false}
                        />
                      )}
                    </React.Fragment>
                  );
                })}

              {unitType === "wardrobe" && loftEnabled && (
                <>
                  <Text
                    x={wardrobeBox.x}
                    y={loftLineY - 18}
                    width={wardrobeBox.width}
                    align="center"
                    text="LOFT"
                    fontSize={12}
                    fontFamily="Arial"
                    fill="#000"
                    listening={false}
                  />
                  {mmRatio > 0 && (
                    <Text
                      x={wardrobeBox.x}
                      y={loftLineY - 4}
                      width={wardrobeBox.width}
                      align="center"
                      text={`${Math.round((loftLineY - wardrobeBox.y) * mmRatio)} mm`}
                      fontSize={11}
                      fontFamily="Arial"
                      fill="#000"
                      listening={false}
                    />
                  )}
                </>
              )}

              <Text
                x={wardrobeBox.x}
                y={wardrobeBox.y - 16}
                width={wardrobeBox.width}
                align="center"
                text="Width"
                fontSize={14}
                fill="#1d4ed8"
              />

              <Text
                x={wardrobeBox.x + wardrobeBox.width + 6}
                y={wardrobeBox.y + wardrobeBox.height / 2 - 8}
                text="Height"
                fontSize={14}
                fill="#1d4ed8"
              />

              {scaleRatio > 0 && (
                <>
                  <Text
                    x={wardrobeBox.x}
                    y={wardrobeBox.y + wardrobeBox.height + 6}
                    text={`Width: ${(wardrobeBox.width * scaleRatio).toFixed(0)} mm`}
                    fontSize={12}
                    fill="#111827"
                  />
                  <Text
                    x={wardrobeBox.x}
                    y={wardrobeBox.y + wardrobeBox.height + 22}
                    text={`Height: ${(wardrobeBox.height * scaleRatio).toFixed(0)} mm`}
                    fontSize={12}
                    fill="#111827"
                  />
                  {wardrobeSpec && (
                    <>
                      <Text
                        x={wardrobeBox.x}
                        y={wardrobeBox.y + wardrobeBox.height + 38}
                        text={`Depth: ${wardrobeSpec.depthMm} mm`}
                        fontSize={12}
                        fill="#111827"
                      />
                      <Text
                        x={wardrobeBox.x}
                        y={wardrobeBox.y + wardrobeBox.height + 54}
                        text={`Shutter Area: ${wardrobeSpec.shutterAreaSqft.toFixed(2)} sqft`}
                        fontSize={12}
                        fill="#111827"
                      />
                    </>
                  )}
                </>
              )}

              {!locked && (
                <Transformer
                  ref={transformerRef}
                  rotateEnabled={false}
                  visible={
                    !useVisualQuotationStore.getState().isCornerResizing &&
                    !edgeResizeOnly
                  }
                  enabledAnchors={["top-left", "top-right", "bottom-left", "bottom-right"]}
                  boundBoxFunc={(oldBox, newBox) => {
                    const width = Math.max(newBox.width, MIN_BOX_SIZE);
                    const height = Math.max(newBox.height, MIN_BOX_SIZE);
                    return {
                      ...newBox,
                      width,
                      height,
                    };
                  }}
                />
              )}
            </>
          )}

          {aiComponentRects.map((component) => (
            <Rect
              key={component.id}
              x={component.x}
              y={component.y}
              width={component.width}
              height={component.height}
              stroke="#f59e0b"
              strokeWidth={1}
              dash={[6, 4]}
              fill="rgba(245, 158, 11, 0.08)"
              listening={false}
            />
          ))}

          {draftBox && (
            <Rect
              x={draftBox.x}
              y={draftBox.y}
              width={draftBox.width}
              height={draftBox.height}
              stroke="#10b981"
              strokeWidth={2}
              dash={[4, 4]}
            />
          )}

          {!hasPhoto && (
            <Text
              x={0}
              y={CANVAS_HEIGHT / 2 - 10}
              width={CANVAS_WIDTH}
              align="center"
              text="Upload or capture room photo to begin"
              fontSize={16}
              fill="#6b7280"
            />
          )}
        </Layer>
      </Stage>
      {unitType === "wardrobe" && loftBox && !loftBox.locked && (
        <button type="button" onClick={lockLoft} style={styles.loftButton}>
          Approve Loft
        </button>
      )}
    </div>
  );
};

export default CanvasStage;

const styles: { [k: string]: React.CSSProperties } = {
  wrapper: {
    position: "relative",
    background: "#fff",
    border: "1px solid #e5e7eb",
    borderRadius: 8,
    padding: 8,
  },
  stage: {
    background: "#f9fafb",
  },
  controlsRow: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 6,
  },
  edgeToggle: {
    display: "flex",
    alignItems: "center",
    fontSize: 12,
    color: "#111827",
    cursor: "pointer",
  },
  loftButton: {
    marginTop: 8,
    padding: "6px 12px",
    borderRadius: 4,
    border: "1px solid #333",
    background: "#111",
    color: "#fff",
    cursor: "pointer",
  },
};
